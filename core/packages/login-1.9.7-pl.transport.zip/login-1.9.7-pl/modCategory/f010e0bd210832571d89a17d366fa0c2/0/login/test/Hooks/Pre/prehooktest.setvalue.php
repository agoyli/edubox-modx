<?php
$hook->setValue('fullname','TestPreValue');
return true;