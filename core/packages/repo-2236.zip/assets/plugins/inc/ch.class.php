<?php
/**
 * $Id: ch.class.php 90 2008-10-21 17:40:06Z stefan $
 * 
 * TODO 
 *  # Parameter organisieren
 *      + Sitzungsparamter $this->getParam('key')
 *      + Standardparamter $this->params['key']
 *  # Generelles aufräumen
 *  # was wird mir der ID wenn der Context eines Dokumentes verlassen wird?
 *  # models erstellen zum holen aller oder eingeschränkter Revisionen
 *    
 */

class Content_History
{
    var $container          = array();
    var $params             = array();
    var $text               = array();
    var $messages           = array();
    var $sysevents          = array();
    var $manager_actions    = array();
    var $revisons_stats     = array();
    var $nocache            = '';
    
    function Content_History( $container )
    {
    
        $this->container        = $container;
        $this->params           = $this->_getParams();
        $this->text             = $this->_getText();
        $this->messages         = $this->_getMessages();
        $this->sysevents        = $this->container['events'];
        $this->manager_actions  = $this->container['manager_actions'];
        $this->nocache          = $this->_noCacheString();
    }

    /**
     * TODO $file muß nicht zwingend gegeben sein. Wenn nicht, einfach nur den Pfad
     * zurückgeben. echo $obj->getSkinUrl('').'path/file';
     *
     * @param unknown_type $file
     * @return unknown
     */
    function getSkinUrl($file)
    {
        if( is_file( $this->params['path'].'skin/'.$this->params['skin'].'/'.$file ) )
        {
            return $this->params['url_rel'].'skin/'.$this->params['skin'].'/'.$file.$this->nocache;  
        }        
        elseif( is_file( $this->params['path'].'skin/default/'.$file ) )
        {
            return $this->params['url_rel'].'skin/default/'.$file.$this->nocache;  
        }
        else
        {
            return false;
        }
    }
    
    /**
     * TODO Datei direkt hier includen, dann muß aber das Objekt mitübergeben werden
     * da das include im context der Klasse läuft. Oder per output-buffer gleich den
     * Text zurückgeben.
     *
     *  @notice Könnte der Einhängepunkt sein um eine Template-engine einzubauen.
     *  
     * @param   string  $file   file to include
     * @return  string          path to file
     */
    function getSkinFile( $file='')
    {
        if( is_file( $this->params['path'].'skin/'.$this->params['skin'].'/'.$file ) )
        {
            return $this->params['path'].'skin/'.$this->params['skin'].'/'.$file;           
            //include $this->params['path'].'skin/'.$this->params['skin'].'/'.$file;           
        }        
        elseif( is_file( $this->params['path'].'skin/default/'.$file ) )
        {
            return $this->params['path'].'skin/default/'.$file;            
            //include $this->params['path'].'skin/default/'.$file;            
        }
        else
        {
           return false;
           //include $this->params['path'].'inc/no_file.phtml';
        }
    }

    function _getTvContentId( $tplvar )
    {
        global $modx;

        $id = $modx->db->getValue(
            $modx->db->select(
                '`id`',
                $this->params['tbl_tplvars_content'],
                "`tmplvarid` = '".$tplvar['tmplvarid']."'".
                " AND `contentid` = '".$tplvar['contentid']."'".
                " LIMIT 0,1"
            )
         );

        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            return (int)$id;
        }
        else
        {
           return 0; 
        }
    }
    /**
     * Delete fields without value from tmplvars_content
     *
     */
    function _cleanTvContentTable()
    {
        global $modx;
        
        $modx->db->delete( 
            $this->params['tbl_tplvars_content'],
            "`value`=''".
            " AND `contentid` = '".$this->params['id']."'"
        );
        
        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            return true;
        }
        else
        {
           return false; 
        }
    }
    
    /**
     * Enter description here...
     *
     * TODO Die Sache mit den leere Einträgen nochmal untersuchen
     */
    function restoreTemplateVar( $tplvar )
    {
        global $modx;

        $is_update_id = $this->_getTvContentId( $tplvar ); 
        if( $is_update_id !== 0 )
        {
            $id = $is_update_id;
            $modx->db->update( 
                $tplvar, 
                $this->params['tbl_tplvars_content'],
                "`id` ='".$id."'"
            ); 
        }
        else // TV ohne Wert hat keine id also wird die mit leerem "value" nun eingetragen...
        {
            //if( !empty($tplvar['value']) ) // klappt grade nicht
            //{
                $modx->db->insert( 
                    $tplvar, 
                    $this->params['tbl_tplvars_content']
                );
            //}
        }

        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            $this->_cleanTvContentTable(); //...und jetzt wieder gelöscht
            return 1;
        }
        else
        {
           return 0; 
        }
    }

    function restoreContentVars( $vars )
    {
        global $modx;

        $_restore_vars = array();
        
        foreach( $vars as $key => $val )
        {
            $_restore_vars[$key] = $modx->db->escape( $val );
        }

        $modx->db->update(
            $_restore_vars, 
            $this->params['tbl_content'],
            '`id`='.$this->params['id']
        );

        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            return true;
        }
        else
        {
           return false; 
        }
    }
    
    function _createRevisionVarsFromActive()
    {
        global $modx;
        
        if( !$source = $this->getActiveDoc())
        {
            return false;
        }
        
        // build array for new insert
        $_vars  = array(
            'ch_doc_rev'        => 1,
            'ch_doc_tplvars'    => $source['tplvars_serial'],
        );
        
        $_vars = array_merge( $_vars, $source['contentvars'] );
    
        if( $this->getParam('mode') === 'upd' )
        {
            $last_rev  = $modx->db->getValue(
                $modx->db->select(
                    'MAX(`ch_doc_rev`)',
                    $this->getParam('tbl_ch'),
                    "`id`='".$this->getParam('id')."'"
                )
            );
            
            if( $last_rev !== NULL )
            {
                $_vars['ch_doc_rev']  = ( (int)$last_rev + 1 );
            }
        }
        
        return $_vars;
    }
    
    function createRevision( $vars=array() )
    {
        global $modx;

        $vars           = $this->_createRevisionVarsFromActive();
        $rev_id         = $vars['ch_doc_rev'];
        $_insert_vars   = array();
        foreach( $vars as $key => $val )
        {
            $_insert_vars[$key] = $modx->db->escape( $val );
        }
    
        $modx->db->insert(
            $_insert_vars, 
            $this->params['tbl_ch']
        );

        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            return $rev_id;
        }
        else
        {
           return false; 
        }
    }

    function _isExistsTplVar( $tplvar )
    {
        global $modx;

        $modx->db->select(
            '`id`',
            $this->params['tbl_tplvars'],
            "`id`='".$tplvar['id']."' LIMIT 0,1"
        );

        $_affectedRows = $modx->db->getAffectedRows();
        if( $_affectedRows !== 0)
        {
            return true;
        }
        else
        {
           return false; 
        }
    }
    
    function deleteRevision( $rev_id, $id=0 )
    {
        global $modx;
        
        if( $id === 0 ) 
        {
            $id = $this->params['id'];
        }

        $res = $modx->db->delete(
            $this->params['tbl_ch'],
            "`ch_doc_rev`='".$rev_id."'".
            " AND `id`='".$id."'"
        );

        $_affected_rows = $modx->db->getAffectedRows();
        return $_affected_rows;
    }

    /**
     * Enter description here...
     *
     * @param unknown_type $id
     * @return unknown
     */
    function deleteAllRevisionsByDoc( $id = 0 )
    {
        global $modx;
        
        if( $id === 0 ) 
        {
           return false;
        }

        $res = $modx->db->delete(
            $this->params['tbl_ch'],
            " `id`='".$id."'"
        );
        
        $_affected_rows = $modx->db->getAffectedRows();
        return $_affected_rows;    
   }

    /**
     * Enter description here...
     *
     * @return unknown
     */
    function getActiveDoc($id=0)
    {
        global $modx;

        if( $id === 0 )
        {
            $id = $this->params['id'];
        }

        $doc_published = $modx->db->getValue( 
            $modx->db->select(
                'published', 
                $this->params['tbl_content'],
                "`id`='".$id."'"
            )
        );
        
        $doc_vars = $modx->getTemplateVars(
            '*',
            '*', 
            $id,
            $doc_published
        );

        if( !$doc_vars )
        {
            return false;
        }
        
        $doc                     = array();
        $doc['tplvars']          = array();
        $doc['tplvars_serial']   = '';
        $doc['tplvars_full']     = array();
        $doc['contentvars']      = array();
        $doc['content_tpl_vars'] = array();
        
        foreach( $doc_vars as $vars )
        {
            if( isset( $vars['id'] ) ) // in_array( $this->container['contentvars'])
            {
                $doc['tplvars_full'][]          = $vars;
                $doc['tplvars'][$vars['name']]  = $vars['value'];
            }
            else
            {
                $doc['contentvars'][$vars['name']]  = $vars['value']; 
            }
        }
        
        $doc['tplvars_serial']   = serialize( $doc['tplvars_full'] );
        $doc['content_tpl_vars'] = array_merge( $doc['contentvars'], $doc['tplvars'] );
                
        return $doc;
    }

    
    /**
     * Enter description here...
     *
     * @return unknown
     */
    function getRevision($rev_id, $id=0)
    {
        global $modx;

        if( $id === 0 )
        {
            $id = $this->params['id'];
        }
        
        $_rev = $modx->db->getRow(
            $modx->db->select(
                '*', 
                $this->params['tbl_ch'],
                "`ch_doc_rev`='".$rev_id."' ".
                " AND `id`='".$id."'"
            )
        );

        if( is_array( $_rev ) )
        {
            $rev                     = array();
            $rev['contentvars']      = array();
            $rev['tplvars']          = array();
            $rev['content_tpl_vars'] = array();
            $rev['tplvars_full']     = array();
            
            if( !empty( $_rev['ch_doc_tplvars'] ) )
            {
                $rev['tplvars_full'] = unserialize( $_rev['ch_doc_tplvars'] );    
                foreach( $rev['tplvars_full'] as $tplvar )
                {
                    $rev['tplvars'][$tplvar['name']]  = $tplvar['value'];
                }
            }
    
            /**
             * TODO eine bessere Lösung finden, der Umstand hier ist nur nötig
             * um einen Eintrag in die site_content Tabelle zu übernehmen
             */
            $rev['ch_id']       = $_rev['ch_id'];
            $rev['ch_doc_rev']  = $_rev['ch_doc_rev'];

            // delete plugincolumns
            unset( $_rev['ch_id'] );
            unset( $_rev['ch_doc_rev'] );
            unset( $_rev['ch_doc_tplvars'] );

            $rev['contentvars'] = $_rev;

            $rev['content_tpl_vars'] = array_merge( $rev['contentvars'],$rev['tplvars'] );
            
            return $rev;
        }
        else
        {
            return false;
        }
    }
    
    function _buildRevisionsStats($id)
    {
        global $modx;
        if(!$id)
        {
            return false;
        }
        // get stats
        $stats =  $modx->db->select(
            'COUNT(`id`)        as `count`,'.
            ' MAX(`ch_doc_rev`)  as `highest`,'.
            ' MIN(`ch_doc_rev`)  as `lowest`,'.
            ' MAX(`editedon`)    as `latest`,'.
            ' MIN(`editedon`)    as `oldest`',
            $this->params['tbl_ch'],
            "`id`='".$id."'"
        );

        $_affected_rows = $modx->db->getAffectedRows();
        if( $_affected_rows > 0)
        {
            $_stats = $modx->db->getRow( $stats );
            $this->setRevisionsStat( $_stats );
            return true;
        }
        else
        {
            return false;
        }
    }
    
   /**
    * Enter description here...
    * 
    * TODO: wenn view_limit noch in der Session steht, wird auch bei neuem
    * Dokument ein Treffer zurückgegeben
    *
    * @param unknown_type $id
    * @return unknown
    */
    function getRevisions($id=0)
    {
        global $modx;

        if( $id === 0 )
        {
            $id = $this->params['id'];
        }
        // erstelle Statistik
        if( !$this->_buildRevisionsStats($id) )
        {
            return false;
        }
            
        if( $this->params['view_limit'] === 'none' )
        {
            $_limit = '';
        }
        else
        {
           $_limit =  ' LIMIT 0,'.$this->params['view_limit'];
        }
        
        $res =  $modx->db->select(
            '*',
            $this->params['tbl_ch'],
            "`id`='".$id."'",
            ' `editedon` DESC'.
            $_limit
            //' LIMIT 0,'.$this->params['view_limit']
        );
       
        $_affected_rows = $modx->db->getAffectedRows();
        if( $_affected_rows > 0 )
        {
            $_revisions = $modx->db->makeArray($res);
            $revisions = array();
            foreach( $_revisions as $_revision )
            {
                $revisions[] = $this->getRevision( $_revision['ch_doc_rev']);
            }
            return $revisions;
        }
        else
        {
            return false;
        }
    }
    
    /**
     * Enter description here...
     *
     * @param mixed $key    kann ein Array sein oder Schlüssel
     * @param string $value
     * @return unknown
     */
    function setRevisionsStat($key, $value='')
    {
        if( is_array( $key ) )
        {
            foreach( $key as $name => $value )
            {
                $_SESSION['ch']['params']['revisions_stats'][$this->params['id']][$name] = $value;
            }
        }
        else
        {
            $_SESSION['ch']['params']['revisions_stats'][$this->params['id']][$key] = $value;
        }
        
        return null;
    }
    
    function getRevisionsStat($key)
    {
        return $_SESSION['ch']['params']['revisions_stats'][$this->params['id']][$key];
    }

    function getDocTemplate( $template_id )
    {
        global $modx;
        $template_name = $modx->db->getValue( 
            $modx->db->select(
                'templatename',
                $this->params['tbl_tpl'],
                "`id`='".(int)$template_id."'"
            )
        );
        return $template_name;
    }

    function _getMessages()
    {
        /**
         * FIXME Das mit den Meldungen richten. Wenn die session zurückgesetzt
         * wird, kommt nicht immer was raus. Beim wiederherstellen gibt es dann
         * eine Meldung, beim "weiterbearbeiten" nicht mehr.
         */
        //$this->_resetMessages();
        return $this->container['messages'];
    }
    
    function _setMessage($pri, $message)
    {
        $_SESSION['ch']['messages'][$pri][] = $message;
        //$this->container['messages'][$pri][] = $message;
        return null;
    }
    
    function resetMessages()
    {
        //$this->container['messages'] = array();
        $_SESSION['ch']['messages'] = array();
        return null;
    }
    
    function log( $level=1, $message, $pri= 'log')
    {
        $_message = array(
            'level' => $level,
            'txt'   => $message
        );
        $this->_setMessage($pri,$_message);
        return null;
    }
    
    function txt($string)
    {
        if( in_array( $string, array_keys( $this->text ) ) )
        {
            $string = $this->text[$string];
        }
        
        if( $this->param['translate'] === 'true' )
        {
            if( !$_SESSION['ch']['txt'] )
            {
                $_SESSION['ch']['txt'] = array();
            }
            /**
             * TODO das ist kein assoc, es gibt nur schlüssel
             */
            // if( !in_array( $string, $_SESSION['ch']['txt'] ) )
            if( !in_array( $string, array_keys( $_SESSION['ch']['txt'] ) ) )
            {
                $_SESSION['ch']['txt'][$string] = $string;
            }
        }
        return $string; 
    }
    
    /**
     * TODO die Text in die Session schreiben
     *
     * @param unknown_type $from
     * @return unknown
     */
    function _getText( $from = 'left')
    {
        $text = array();
        $language_file = $this->params['path'].'lang/'.$this->params['language'].'.txt';
        if( file_exists( $language_file ) )
        {
            $source = file_get_contents( $language_file );
            $lines = explode("\n", $source);
            foreach( $lines as $line )
            {
                $line = trim($line);
                if( $line !==''
                    && !preg_match('/^##/',$line) )
                {
                    $text_kv         = explode('==',$line,2);
                    $text_key        = trim($text_kv[0]);
                    $text_val        = trim($text_kv[1]);
                    $text[$text_key]  = $text_val;
                }
            }
        }
        return $text;
    }

    /**
     * Enter description here...
     *
     * @param unknown_type $params
     * @return unknown
     */
    function setParam($key,$value)
    {
       $this->container['params'][$key] = $value;
       $_SESSION['ch']['params'][$key] = $value;       
       return null;
    } 
    
    function getParam($key)
    {
        /*
        if( $value = $_SESSION['ch']['params'][$key] )
        {
            return $value;
        }
        elseif( $value = $this->container['params'][$key] )
        {
            return $value;
        }
        */
        
        if( $value = $this->container['params'][$key] )
        {
            return $value;
        }
        return false;
    } 

    function _getParams()
    {
        if( is_array( $this->container['params'] ) )
        {
           return $this->container['params'];
        }
        return false;
    } 
    /**
     * Kein cahce
     */
    function _noCacheString()
    {
        if( $this->params['prevent_caching'] === 'true')
        {
            $string = '?'.uniqid();
        }
        else
        {
            $string ='';
        }
        return $string;
    }
}