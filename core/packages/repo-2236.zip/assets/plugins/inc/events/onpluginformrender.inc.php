<?php
/**
 * $Id: onpluginformrender.inc.php 90 2008-10-21 17:40:06Z stefan $
 * 
 */
?>
<?php

/**
 * TODO: Datentabelle nur einmal checken
 */


ob_start();
/**
 * TODO Tabelle nur einmal erstellen
 */
include_once $ch->params['path'].'/inc/create_table.inc.php';
include $ch->getSkinFile('tpl/plugin_formrender.tpl.phtml');
$e_output = ob_get_clean();
$e->output( $e_output );