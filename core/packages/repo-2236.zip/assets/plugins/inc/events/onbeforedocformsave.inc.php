<?php
/**
 * $Id: onbeforedocformsave.inc.php 73 2008-10-19 12:29:13Z stefan $
 *
 * TODO Entwurfsmodus einbauen Revision "0" immer updaten statt in die richtige
 * Tabelle zu schreiben. Anschließend redirct zur Bearbeitungsseite.
 */

//if( $_POST['ch']['beforesave'] )
if( $ch->getParam('draftmode') === 'true' )
{
    $ch->log(1,'draftmode');
    //$ch->createDraftRevision(); // create revision "0"
    //$ch->updateRevision();      // update revision "0"
    //$modx->sendRedirect();      
    exit;
}