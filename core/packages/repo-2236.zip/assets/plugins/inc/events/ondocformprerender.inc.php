<?php
/**
 * $Id: ondocformprerender.inc.php 90 2008-10-21 17:40:06Z stefan $
 * 
 * TODO Aktionen löschen und restore können bei managerpageinit und den 
 * passenden manageractions ausgeführt werden mit einem redirect wenn die Aktion
 * durchlaufen ist. 
 * 
 * Meldungen zurücksetzen nur wenn die Aktionen ausgeführt werden, da sonst
 * auch die Meldung über erfolgten Eintrag gelöscht werden 
 */
?>
<?
/**
 * setze Parameter für das neuladen des Baumes
 * 
 * Wenn ein Eintrag wiederhergestellt wird, wird nicht automatisch der Baum
 * aktualisiert. Das verwirrt. Wenn "reload_tree" "true" ist, wird im 
 * Scriptblock des Templates "top.mainMenu.reloadtree();" aufgerufen.
 * 
 * Der Parameter kommt aus der Session, darum hier erst wieder auf false 
 * Wenn "restore" angefordert ist, setze wieder auf "true".
 * Siehe unten if( isset( $_GET[ch_restore] ) )
 * TODO Parameter "reload_tree" überleg mal ob das nicht scheißegal ist
 */
$ch->setParam('reload_tree','false');

// wenn neues Dokument lösche alle Meldungen
// TODO besser machen
if( $ch->getParam('current_doc_id') !== $ch->getParam('id') )
{
    $ch->setParam('current_doc_id', $ch->getParam('id') );
    $ch->resetMessages();
}

if( isset( $_GET['a'] )
    && $_GET['a'] === '4' )
{
    $ch->setParam('current_doc_id', 0 );
    $ch->resetMessages();
}

// set view_limit 
if( isset( $_GET['ch_view_limit'] )
    && !empty( $_GET['ch_view_limit'] ) )
{
    $ch->resetMessages();
    $_view_limit = (int)$_GET['ch_view_limit'];
    
    if( $_GET['ch_view_limit'] === 'none' ) 
    {
        $_view_limit = $_GET['ch_view_limit'];   
    }
    $ch->setParam('view_limit', $_view_limit );
    // $ch->log(1, sprintf( $ch->txt('Anzeige limit auf <strong>%s Zeilen</strong> gesetzt'), $_view_limit ), 'head' );
}

/**
 * Eintrag aus der Geschichte löschen
 */
if( isset( $_GET['ch_delete'] )
    && !empty( $_GET['ch_delete'] ) )
{
    $ch->resetMessages();
    
    $ch_doc_rev = (int)$_GET['ch_delete'];
    $res        = $ch->deleteRevision($ch_doc_rev);
    switch( $res )
    {
        case 1:
            $ch->log(1, sprintf( $ch->txt('Version <strong>%s</strong> wurde gelöscht'), $ch_doc_rev), 'head' ); 
            break;
        case 0:
            $ch->log(2, sprintf( $ch->txt('Version <strong>%s</strong> Nicht gefunden. Konnte nicht gelöscht werden.'), $ch_doc_rev), 'head');
            break;
        default:
            $ch->log(3, sprintf( $ch->txt('Kann das sein? %s - Zeile %s'), __FILE__,__LINE__ ), 'head' );
            break;
    }
}

/**
 * bulk_delete
 */
if( isset( $_GET['ch_bulk_delete'] )
    && !empty( $_GET['ch_bulk_delete'] ) )
{
    $ch->resetMessages();

    $_rev_ids = explode(',',$_GET['ch_bulk_delete'] );
    foreach( $_rev_ids as $rev_id )
    {
        $ch_doc_rev = (int)$rev_id;
        $res        = $ch->deleteRevision($ch_doc_rev);
        if( is_int($res) )
        {
            switch( $res )
            {
                case 1:
                    $ch->log(1, sprintf( $ch->txt('Version <strong>%s</strong> wurde gelöscht'), $ch_doc_rev), 'head' ); 
                    break;
                case 0:
                    $ch->log(2, sprintf( $ch->txt('Version <strong>%s</strong> Nicht gefunden. Konnte nicht gelöscht werden.'), $ch_doc_rev), 'head');
                    break;
                default:
                    $ch->log(3, sprintf( $ch->txt('Kann das sein? %s - Zeile %s'), __FILE__,__LINE__ ), 'head' );
                    break;
            }
        }
        else
        {
            $ch->log(3, sprintf( $ch->txt('Irgendwas läuft schief! in %s - Zeile: %s'), __FILE__,__LINE__ ), 'head' );    
        }
    }
}
/**
 * restore content-vars and template-vars
 * 
 * TODO beim zurücksetzen wird das alte editedon-Datum verwendet.
 * Gibt es da ein Problem? Wenn man beim zurücksetzen now() als neue Zeit 
 * einträgt, da ja das Dokument/die öffentliche Quellt tatsächlich heute neu 
 * "editiert" wurde, stimmt aber die Sortierung der Versionsnummer nicht mehr, 
 * da nach "editedon" sortiert wird. Überleg mal.
 */
if( isset( $_GET['ch_restore'] )
    && !empty( $_GET['ch_restore'] ) )
{
    $ch->resetMessages();
    
    /**
     * content-vars wiederherstellen / Inhalt von site_content
     */
    $ch_rev_id = (int)$_GET['ch_restore'];
    if( !$ch_doc_rev = $ch->getRevision( $ch_rev_id ) )
    {
        $ch->log(2, sprintf( $ch->txt('Version <strong>%s</strong> Nicht gefunden. Konnte nicht wiederhergestellt werden.'), $ch_rev_id ),'head' );
        return;
    }

    switch( $_restore = $ch->restoreContentVars( $ch_doc_rev['contentvars'] )  )
    {
        case true:
            $ch->log( 1, sprintf( $ch->txt('Version <strong>%s</strong> wiederhergestellt'), $ch_rev_id  ), 'head' );
            break;
        case false:
            $ch->log( 2, sprintf( $ch->txt('Version <strong>%s</strong> ist bereits die aktuelle Version, keine Änderungen'), $ch_rev_id  ), 'head' );
            break;
        default:
            $ch->log( 3, sprintf( $ch->txt('Kann das sein? %s - Zeile: %s'),__FILE__,__LINE__) ); 
            break;
    }
    //$ch->log(1,$_restore);

    /**
     * Über schreibe das gelieferte content array mit den Werten der 
     * wiederhergestellen Version.
     * 
     * TODO siehe Hinweis im Kommentar ganz oben. Wenn mit redirect weitergeletet
     * wäre dieser Schritt unnötig. überlege mal was besser ist. 
     */
    $content = $ch_doc_rev['contentvars'];
    
    /**
     * Setze reload_tree auf true, damit der Baum aktualisiert wird.
     * siehe Kommentar oben.
     */
    $ch->setParam('reload_tree','true');
    
    /**
     *  Restore templatevars
     */
    if( $_tplvars_full = $ch_doc_rev['tplvars_full'] )
    {
        foreach( $_tplvars_full as $tplvar )
        {
            // Ist die TV überhaupt noch im System vorhanden oder mittlerweile gelöscht.
            if( $_exists = $ch->_isExistsTplVar( $tplvar ) )
            {
                //$ch->log( 1, $tplvar['name'].' gibts' ); 
                $tplvar_data = array(
                    'tmplvarid' => $tplvar['id'],
                    'contentid' => $ch->params['id'],
                    'value'     => $modx->db->escape( $tplvar['value'] )
                );
                
                /**
                 * FIXME Rückgabewert konntrollieren
                 * Wenn tvs in aktuellem Dokument und in Revision leer, sollte
                 * "keine Änderung" ausgegeben werden, tut es aber nicht. 
                 * restoreTemplateVar( $tplvar ) anschauen.
                 * Wenn die tv keinen Wert enthält, wird erst ein Datenbankeintrag
                 * mit leerem "value" gemacht und der anschließend wieder gelöscht.
                 * Das ist vielleicht die Ursache.
                 */
                $_restore_tv = $ch->restoreTemplateVar( $tplvar_data );
                switch( $_restore_tv )
                {
                    case 1:
                        $ch->log( 1, sprintf( $ch->txt('<strong>%s</strong>(%s) wiederhergestellt'), $tplvar['caption'],$tplvar['name'] ) );
                        break;
                    case 0:
                        $ch->log( 2, sprintf( $ch->txt('<strong>%s</strong>(%s) keine Änderung'), $tplvar['caption'],$tplvar['name'] ) );
                        break;
                }
                //$ch->log(1, $_restore_tv );
            }
            else
            {
               //$ch->log(1, $_exists );
               $ch->log( 3, sprintf( $ch->txt('<strong>%s</strong>(%s) existiert nicht mehr'), $tplvar['caption'],$tplvar['name'] ) ); 
            }
        }
    }

    /**
     * clear cache / frontend
     */
    include_once './processors/cache_sync.class.processor.php';
    $_sync = new synccache();
    $_sync->setCachepath('../assets/cache/');
    $_sync->setReport(false);
    $_sync->emptyCache();
    unset($_sync);
}