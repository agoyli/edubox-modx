<?php
/**
 * $Id: ondocformsave.inc.php 73 2008-10-19 12:29:13Z stefan $
 */
?>
<?php
/**
 * create if "record" is true
 * 
 * FIXME setParam und getParam funktionieren während der Laufzeit,
 * das Param array (params[]) enthält noch den alten Wert und bekommt 
 * den neuen erst nach erneutem reload... Rausfinden warum.
 * $ch->log(1, 'params: '.$ch->params['record'] );
 * $ch->log(1, 'getparam: '.$ch->getParam('record') );
 * 
 * TODO Generell das setzen und auslesen der Parameter verbessern.
 * Nach managerpageinit verschieben.
 * 
 */

// Meldungen zurücksetzen
$ch->resetMessages();

if( isset( $_POST['ch']['record'] )
    && !empty( $_POST['ch']['record'] ) )
{
    $_record = $_POST['ch']['record'];
    switch( $_record )
    {
        case 'true':
            $ch->setParam('record','true');
            break;
        case 'false':
            $ch->setParam('record','false');
            break;
        default: 
            break;
    }
}

if( $ch->getParam('record') === 'true' )
{
    /**
     * TODO hier "prevent_duplicates" einklinken. 
     * is_duplicate ? update/discard : create
     */

    /**
     * Erstelle eine neue Revision aus dem gerade gepeicherten Dokument.
     */
    $_is_created_id = $ch->createRevision();
    switch( $_is_created_id )
    {
        case is_int($_is_created_id):
            $ch->log( 1, sprintf( $ch->txt('Eintrag wurde als Version <strong>%s</strong> gespeichert'), $_is_created_id ),'head');
            break;
        case false:
            $ch->log( 3, sprintf( $ch->txt('FEHLER: Eintrag konnte <strong>nicht</strong> angelegt werden %s - Zeile: %s'),__FILE__,__LINE__ ),'head');
            break;
    }
}
else
{
    $ch->log( 2, $ch->txt('Eintrag wurde <strong>nicht</strong> als Version gespeichert'),'head');
}