<?php
/**
 * $Id: ondocformrender.inc.php 90 2008-10-21 17:40:06Z stefan $
 */
?>
<?php
/**
 * $Id: ondocformrender.inc.php 90 2008-10-21 17:40:06Z stefan $
 * 
 * TODO das aktuelle/aktive Dokument schon im plugin laden, für alle Events
 * die darauf zugreifen wollen. Nicht doppelt also extra in jedem event laden.
 * $ch->getActiveDoc();
 */
ob_start();
if( $_ch_revisions = $ch->getRevisions() )
{
    $ch->resetMessages();
    $active_doc          = $ch->getActiveDoc();
    $ch_revisions        = array();
    $ch_current_revision = array();
    
    $y = 1;
    foreach( $_ch_revisions as $ch_revision )
    {
        //$ch_tpldata                   = $ch_revision['contentvars'];
        $ch_tpldata                   = $ch_revision['content_tpl_vars'];
        $ch_tpldata['tplvars_full']   = $ch_revision['tplvars_full'];
        $ch_tpldata['tplvars']        = $ch_revision['tplvars'];
        
        /**
         * TODO Diffkram ausbauen
         * 
         * Parameter verbauen create_quick_compare, compare_fields, create_diff, diff_fields
         * 
         * Uwe Treeker - info@treeker.net 
         */
        
        if( $ch->getParam('create_diff_container') === 'true')
        {
            require_once 'Text/Diff.php';
            require_once 'Text/Diff/Renderer.php'; 
            require_once 'Text/Diff/Renderer/inline.php'; 
        }
        
        /**
         * Wenn sich das array_diff nicht unterscheidet bis auf editedon, wird
         * der Eintrag gelöscht. Vorerst nur ausblenden
         */
        if( $ch_rev_diff = array_diff_assoc( $active_doc['content_tpl_vars'], $ch_revision['content_tpl_vars'] ) )
        {
            if( count($ch_rev_diff) === 1 
                && in_array( 'editedon' ,array_keys( $ch_rev_diff ) ) )
            {
                /*                
                if( $ch->getParam('prevent_duplicates') === 'true' )
                {
                    if( $ch->deleteRevision($ch_revision['ch_doc_rev'] ) )
                    {
                        $ch->log(1, sprintf('Version %s gelöscht. War bis auf "editedon" identisch mit den aktuellen Dokument.' ,$ch_revision['ch_doc_rev'] ),'head' );   
                    } 
                }
                */
                
                $ch_tpldata['ch_is_duplicate'] = true;               
            }
            else
            {
                /**
                 * TODO Filter einbauen, welche Felder überhaupt angezeigt werden
                 * sollen.
                 */
                $ch_tpldata['ch_diff'] = array_keys( $ch_rev_diff );
                
                /**
                 * TODO Filter einbauen, welche Felder verglichen werden sollen
                 * content... in Konfiguration einbauen, Methode bauen
                 */
                $_use_fields = array('content');
                
                if( $ch->getParam('create_diff_container') === 'true')
                {
                    if( in_array($_use_fields[0], $ch_tpldata['ch_diff'] ) )
                    {
                        $text1[] = $ch_revision['contentvars']['content'];
                        $text2[] = $active_doc['contentvars']['content'];

                        $diff = new Text_Diff($text1, $text2); 
                        if( !$diff->isEmpty() ) 
                        { 
                            $renderer = new Text_Diff_Renderer_inline(); 
                            $diffs = $renderer->render($diff); 
                            $ch_tpldata['ch_diff_content'] = $diffs;
                        }
                    } 
                }// if create_diff_container === true
            }//if array_diff rev:active
        }

        $ch_tpldata['ch_id']            = $ch_revision['ch_id'];
        $ch_tpldata['ch_doc_rev']       = $ch_revision['ch_doc_rev'];
        $ch_tpldata['ch_template_name'] = $ch->getDocTemplate( $ch_revision['contentvars']['template'] );
        $ch_tpldata['ch_user']          = $modx->getUserInfo( $ch_revision['contentvars']['editedby'] );
        $ch_tpldata['ch_iteration']     = $y;
        $ch_tpldata['ch_rowclass']      = ($y%2===0)?'gridItem':'gridAltItem';
        
        /**
         * TODO aktives Dokument holen, wenn nicht im limit enthalten und ganz nach
         * oben setzen.
         */
        if( $active_doc['contentvars']['editedon'] === $ch_revision['contentvars']['editedon'] )
        {
            $ch_tpldata['ch_current_rev']   = true;    
            $ch_current_revision            = $ch_tpldata;             
            //$y--;
        }
        else
        {
            //$ch_revisions[]             = $ch_tpldata;
        }

        $ch_revisions[]             = $ch_tpldata;
        $y++;
        $ch_revisions_exists = true;
    }
}

include $ch->getSkinFile('tpl/content_history.tpl.phtml');
$e_output = ob_get_clean();
$e->output( $e_output );     