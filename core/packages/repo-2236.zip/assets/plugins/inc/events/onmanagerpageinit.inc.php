<?php
/**
 * $Id: onmanagerpageinit.inc.php 90 2008-10-21 17:40:06Z stefan $
 * 
 * stefan@hotzeplotz.de
 */
switch( $modx->manager->action )
{
    // Frames
    case '1':
        switch( $_GET['f'] )
        {
            case 'tree': 
                //  echo 'i am on the tree frame / just at top, not within the nodes';
                // include_once $uix->params['path'].'inc/onmanagerpageinit_leftframe.inc.php';
                break;
            case 'menu':
                // echo 'i am on the top frame';
                break;
            default :
                return;
                break;
        }
        break;
    
    case '2': // Startpate
        if( isset( $_GET['ch_delete_all'] )
            && !empty( $_GET['ch_delete_all'] ) )
        {
            $ch->resetMessages();            
            $ch_doc_id = (int)$_GET['ch_delete_all'];
            $res        = $ch->deleteAllRevisionsByDoc( $ch_doc_id );
            switch( $res )
            {
                case 0:
                    $ch->log(2, $ch->txt('Kein Dokument zum löschen gefunden.'), 'head');
                    break;
                case $res > 0: //TODO is_int($res) && $res > 0
                    $ch->log(1, sprintf( $ch->txt('Dokument <strong>%s</strong> wurde gelöscht. <strong>%s</strong> Revision(en)'), $ch_doc_id, $res), 'head' ); 
                    break;
                default:
                    $ch->log(3, sprintf( $ch->txt('Kann das sein? %s - Zeile %s'), __FILE__,__LINE__ ), 'head' );
                    break;
            }
            header('location:'.$modx->config['site_url'].'/manager/index.php?a=2');
        }
        ob_start();
        include $ch->getSkinFile('tpl/startpage.tpl.phtml');
        ob_flush();
        break;

    case '3':     // Dokumentübersicht
        /**
         * wenn Übersicht aus Baum aufgerufen wird, setze die Meldungen zurück
         * sonst stehen die Meldung auf der Übersicht eines anderen Dokumentes
         * 
         * TODO 
         *  # Meldungen / Paramter / Sessions - Standard
         *  # Model erstellen für das holen aller Einträge.
         */
        // docformrender ist die Funktion zum bauen der Einträge eines Dokumentes
        //include $ch->params['path'].'inc/events/ondocformrender.inc.php';
        if( isset( $_SERVER['HTTP_REFERER'] )
            && strpos($_SERVER['HTTP_REFERER'],'?a=1&') )
        {
            $ch->resetMessages();
        }
        break;
    
    case '7': // waiting-screen nach doc speichern der zwischen schirm mit der "aufräumen" meldung
        ob_start();
        include $ch->getSkinFile('tpl/waiting_screen.tpl.phtml');
        ob_flush();
        $ch->resetMessages();       
        break;
    
    case '4': // neues Dokument
        /**
         * Meldungen zurücksetzen
         */
        //$ch->resetMessages();
        //$ch->setParam('id',0);
        break;
    
    case '27': // Dokument bearbeiten
/*
            if( isset( $_GET['ch_view_limit'] )
                && !empty( $_GET['ch_view_limit'] ) )
            {
                $ch->setParam('id',$_GET['id']);
                $_view_limit = $modx->stripTags( $_GET['ch_view_limit'] );
                $ch->setParam('view_limit', $_view_limit );
            
                $modx->sendRedirect( $modx->config['site_url'].$_SERVER['SCRIPT_NAME'].'?id='.$ch->params['id'].'&a=27' );
                //header('Location:'.$modx->config['site_url'].$_SERVER['SCRIPT_NAME'].'?id='.$ch->params['id'].'&a=27');
                exit;
            }
*/
        break;
    
    default : 
        // echo 'Over all... not good, will demage some things';
        return;
        break;     
}
?>