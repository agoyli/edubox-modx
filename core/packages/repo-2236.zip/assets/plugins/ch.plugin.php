<?php
/**
 * $Id: ch.plugin.php 90 2008-10-21 17:40:06Z stefan $
 * 
 * TODO
 *  # Aktuelles Dokument hier laden wenn manageractions und events passen, damit
 *    es nicht mehrfach aufgerufen werden muß.
 *  # Meldungen reorganisieren, damit die nicht immer komplett zurückgesetzt
 *    werden. Namensräume erstellen? manager-actions?
 *    + ch->log > ch->messages > ch-resetMessages auf einer Seite geht nicht.
 *  # Parameter organisieren / Standardwerte als fallback
 *    + ch->getParam('key') für die Sitzungseinstellungen  
 *    + ch->param['key'] für die Standardparameter
 *    + Parameter Dokumentbezogen speichern, so wie die stats
 *  # Das ch Objekt globalisieren, damit nicht immer neu geladen
 *      global $ch;
 *      if( !is_object( $ch ) )
 *      {
 *          include_once realpath( dirname(__FILE__) ).'/inc/ch.class.php';
 *          $ch = new Content_History( $_ch_container );    
 *      }
 *      Funktioniert nicht wie gewollt, die Parameter werden nicht verschmolzen
 * 
 * FIXME Wenn man die Meldungen nicht zurücksetzt kann man generell eine
 * Merkwürdigkeit beobachten. Beim löschen oder oder wiederherstellen 
 * einer Version bleiben in $_SESSION['ch']['messages'] immer zwei Einträge hängen.
 * Löscht man Version 2 von doc1, gib es die Meldung "v2 gelöscht". Beim nächsten 
 * Klick steht eine weitere Meldung "v2 nicht gelöscht" im log... als wäre die jeweilige
 * Aktion zweimal durchgeführt worden. Untersuchen.
 * 
 */
?>
<?php
global $e;
$e = &$modx->event;
$_ch_container = array(
    'params' => array(
        'version'               => '0.2.4',
        'path'                  => MODX_BASE_PATH.$params['rel_path'],
        'path'                  => realpath( dirname(__FILE__) ).'/',
        'inc_path'              => realpath( dirname(__FILE__) ).'/inc/',
        'url'                   => $params['url_rel'],
        'draftmode'             => 'false',
        'skin'                  => 'default',
        'record'                => 'true',
        'language'              => $modx->config['manager_language'],
        'lang_reference'        => 'english.txt',
        'tbl_content'           => $modx->getFullTableName('site_content'),
        'tbl_ch'                => $modx->getFullTableName('site_content_history'),
        'tbl_tplvars'           => $modx->getFullTableName('site_tmplvars'),
        'tbl_tplvars_content'   => $modx->getFullTableName('site_tmplvar_contentvalues'),
        'tbl_tpl'               => $modx->getFullTableName('site_templates')
    ),
    'session_params' => array(),
    'content_vars' => array(
        'alias','cacheable','content','contentType','content_dispo','createdby',
        'createdon','deleted','deletedby','deletedon','description','donthit',
        'editedby','editedon','haskeywords','hasmetatags','hidemenu','id',
        'introtext','isfolder','link_attributes','longtitle','menuindex',
        'menutitle','pagetitle','parent','privatemgr','privateweb','pub_date',
        'published','publishedby','publishedon','richtext','searchable',
        'template','type','unpub_date'
    ),
    'events' => array(
        'OnManagerPageInit'     => 89,
        'OnDocFormPrerender'    => 28,
        'OnDocFormRender'       => 29,
        'OnBeforeDocFormSave'   => 30,
        'OnDocFormSave'         => 31,
        'OnPluginFormRender'    => 35
    ),
    'manager_actions' => array(
        1,      // top/left frame | different by $_GET['f']
        2,      // startpage
        3,      // Dokumentübersicht
        4,      // neues Dokument
        7,      // waiting-screen
        27,     // document update 
        72,     // weblink
        102,    // pluginform render
        103     // pluginform save
    ),
    'messages' => array()
);

if( in_array( $e->name, array_keys( $_ch_container['events'] ),1 ) )
{
    global $_lang, $content;

    if( isset(  $params ) 
        && is_array( $params ) )
    {
        $_ch_container['params'] = array_merge( $_ch_container['params'], $params );
    }

    if( isset(  $_SESSION['ch']['params'] ) 
        &&is_array( $_SESSION['ch']['params'] ) )
    {
        $_ch_container['params'] = array_merge( $_ch_container['params'], $_SESSION['ch']['params'] );
    }

    /**
     * FIXME Die Meldungen dürfen hier nicht verschmolzen werden, sondern
     * erst in der Klasse. Sonst gibt es Problem mit gepeicherten und bereits
     * zurückgesetzen Meldungen siehe setMessage,getMessage,resetMessage
     */
    if( isset( $_SESSION['ch']['messages'] )
        &&is_array( $_SESSION['ch']['messages'] ) )
    {
        $_ch_container['messages'] = array_merge( $_ch_container['messages'], $_SESSION['ch']['messages'] );
    }
    else
    {
        $_SESSION['ch']['messages'] = array();
    }

    /**
     * TODO Das Objekt wenn möglich nur einmal laden und globalisieren statt es bei
     * jedem Aufruf neu zu laden. Vielleicht wenn onmanagerpageinit. 
     * Klappt aber im Moment nicht.
     */
    include_once realpath( dirname(__FILE__) ).'/inc/ch.class.php';
    $ch = new Content_History( $_ch_container );
    
    /**
     * Wenn die id des aktuellen Dokumentes nicht im params array steht, wird sie
     * per $_GET übergeben, wie auf der Dokumenten-Übersichtseite
     * 
     * TODO erst aktivieren, wenns auch geht. solange direkt get benutzen
     */
    /*
    if( $id != $ch->getParam('id') ) a 3, 7?
    {
        if( $id = $_GET['id'] )
        { 
            $ch->setParam('id',$_GET['id']);    
        }
    }
    */
        
    // include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
    switch( $e->name )
    {
        case 'OnManagerPageInit': // wird jedesmal ausgeführt
            include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            break;
    
        case 'OnDocFormPrerender' :
            include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            break;
            
        case 'OnDocFormRender':
            include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            break;
        
        case 'OnBeforeDocFormSave':
            //include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            break;
          
        case 'OnDocFormSave':
            include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            break;
    
        case 'OnPluginFormRender':
            $current_plugin = $content['name'];
            if( strtolower( $current_plugin ) === 'content_history' ) //TODO set variable plugin_name
            {
                include_once $ch->params['path'].'inc/events/'.strtolower( $e->name ).'.inc.php';
            }
            break;
            
        default: 
            return; 
            break;
    }
}
return;